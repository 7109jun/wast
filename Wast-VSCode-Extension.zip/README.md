# Wast Language Support

VS Code support for the Wast language implemented by `wast2.cpp`.

## Features

- `.wast` language mode
- Syntax highlighting based on the lexer tokens in `wast2.cpp`
- Keyword/type/snippet completion
- `Wast: Setup / Build Engine`
- `Wast: Transpile Current File`
- `Wast: Run Current File`
- Automatically downloads the configured `wast2.cpp` source and compiles it with the user's `g++`
- Runs generated programs in the VS Code integrated terminal

## Requirements

- VS Code 1.85+
- `g++` available in PATH
- A GCC version with C++23 support (`std::print` is used by the current engine)

## Install

This ZIP is an extension project. Extract it, open the folder in VS Code, then use **Extensions: Install from VSIX...** after packaging it as a VSIX, or run the folder as an extension-development workspace with **F5**.

The extension does not bundle a native binary. On first setup it downloads `wast2.cpp` from the configured source URL and builds it locally with `g++`.

## Commands

- `Wast: Setup / Build Engine`
- `Wast: Transpile Current File`
- `Wast: Run Current File`

## Settings

- `wast.compiler`
- `wast.enginePath`
- `wast.sourceUrl`

Source engine: https://github.com/7109jun/--/blob/main/wast2.cpp
