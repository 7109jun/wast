const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');
const https = require('https');

let enginePromise = null;

const KEYWORDS = [
  'fn','local','const','if','elseif','else','while','for','in',
  'return','break','continue','true','false','nil','and','or','not',
  'struct','enum','match','library'
];
const TYPES = [
  'i8','i16','i32','i64','u8','u16','u32','u64','f32','f64',
  'bool','string','str','void','any'
];

function cfg() {
  return vscode.workspace.getConfiguration('wast');
}

function outputChannel() {
  return vscode.window.createOutputChannel('Wast');
}

function run(command, args, cwd, channel) {
  return new Promise((resolve, reject) => {
    const p = cp.spawn(command, args, {
      cwd,
      windowsHide: true,
      shell: false
    });
    let stdout = '', stderr = '';
    p.stdout.on('data', d => { stdout += d.toString(); channel.append(d.toString()); });
    p.stderr.on('data', d => { stderr += d.toString(); channel.append(d.toString()); });
    p.on('error', reject);
    p.on('close', code => resolve({code, stdout, stderr}));
  });
}

function commandExists(command) {
  return new Promise(resolve => {
    const probe = process.platform === 'win32' ? 'where' : 'which';
    cp.execFile(probe, [command], {windowsHide:true}, (err) => resolve(!err));
  });
}

function download(url, target) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(target);
    https.get(url, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close(); try { fs.unlinkSync(target); } catch {}
        return download(res.headers.location, target).then(resolve, reject);
      }
      if (res.statusCode !== 200) {
        file.close(); try { fs.unlinkSync(target); } catch {}
        return reject(new Error(`Download failed: HTTP ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => file.close(resolve));
    }).on('error', err => {
      file.close(); try { fs.unlinkSync(target); } catch {}
      reject(err);
    });
  });
}

function engineDir(context) {
  const dir = path.join(context.globalStorageUri.fsPath, 'engine');
  fs.mkdirSync(dir, {recursive:true});
  return dir;
}

async function ensureEngine(context, force=false) {
  if (enginePromise && !force) return enginePromise;
  enginePromise = (async () => {
    const channel = outputChannel();
    channel.show(true);
    const compiler = cfg().get('compiler', 'g++');
    const configured = cfg().get('enginePath', '');
    if (configured && fs.existsSync(configured)) return configured;

    if (!(await commandExists(compiler))) {
      throw new Error(`g++ was not found in PATH. Set wast.compiler or install GCC.`);
    }

    const dir = engineDir(context);
    const source = path.join(dir, 'wast2.cpp');
    const exe = path.join(dir, process.platform === 'win32' ? 'wast2.exe' : 'wast2');

    if (force || !fs.existsSync(source)) {
      channel.appendLine(`Downloading wast2.cpp...`);
      await download(cfg().get('sourceUrl'), source);
    }

    if (force || !fs.existsSync(exe)) {
      channel.appendLine(`Compiling wast2.cpp with ${compiler}...`);
      const args = ['-std=c++23','-O2',source,'-o',exe];
      const result = await run(compiler,args,dir,channel);
      if (result.code !== 0) throw new Error(`wast2.cpp compilation failed (exit ${result.code}).`);
    }
    return exe;
  })();
  try { return await enginePromise; }
  catch (e) { enginePromise = null; throw e; }
}

function generatedCpp(file) {
  return file + '.cpp';
}

function generatedExe(file) {
  return file + (process.platform === 'win32' ? '.exe' : '.out');
}

async function transpile(context, file) {
  const engine = await ensureEngine(context);
  const dir = path.dirname(file);
  const out = generatedCpp(file);
  const channel = outputChannel();
  channel.show(true);
  const result = await run(engine,[file,out],dir,channel);
  if (result.code !== 0) throw new Error(`Wast transpilation failed (exit ${result.code}).`);
  return out;
}

async function buildProgram(context, file) {
  const cpp = await transpile(context,file);
  const compiler = cfg().get('compiler','g++');
  const exe = generatedExe(file);
  const channel = outputChannel();
  const result = await run(compiler,['-std=c++23','-O2',cpp,'-o',exe],path.dirname(file),channel);
  if (result.code !== 0) throw new Error(`Generated C++ compilation failed (exit ${result.code}).`);
  return exe;
}

function runInTerminal(file, exe) {
  const terminal = vscode.window.createTerminal({name:'Wast', cwd:path.dirname(file)});
  terminal.show(true);
  const q = s => process.platform === 'win32' ? `"${s.replace(/"/g,'""')}"` : `'${s.replace(/'/g,"'\\''")}'`;
  terminal.sendText(q(exe), true);
}

function registerCompletion(context) {
  const provider = vscode.languages.registerCompletionItemProvider('wast', {
    provideCompletionItems() {
      const items = [];
      for (const k of KEYWORDS) {
        const i = new vscode.CompletionItem(k, vscode.CompletionItemKind.Keyword);
        i.detail = 'Wast keyword';
        items.push(i);
      }
      for (const t of TYPES) {
        const i = new vscode.CompletionItem(t, vscode.CompletionItemKind.TypeParameter);
        i.detail = 'Wast type';
        items.push(i);
      }
      const templates = [
        ['fn','fn ${1:name}(${2:args}) (${3:\\n\\t$0\\n})'],
        ['local','local ${1:name} = ${2:value}'],
        ['if','if ${1:condition} (\\n\\t$0\\n)'],
        ['for','for ${1:i} in ${2:start}..${3:end} (\\n\\t$0\\n)'],
        ['match','match ${1:value} (\\n\\t${2:pattern} -> ${3:value}\\n)'],
        ['library','library ${1:name}(${2:args}) -> ${3:i64} \\"\\"\\"\\n${4:return 0;}\\n\\"\\"\\"']
      ];
      for (const [label, body] of templates) {
        const i = new vscode.CompletionItem(label, vscode.CompletionItemKind.Snippet);
        i.insertText = new vscode.SnippetString(body);
        i.detail = 'Wast snippet';
        items.push(i);
      }
      return items;
    }
  });
  context.subscriptions.push(provider);
}

function activate(context) {
  registerCompletion(context);

  context.subscriptions.push(vscode.commands.registerCommand('wast.setup', async () => {
    try {
      const engine = await ensureEngine(context,true);
      vscode.window.showInformationMessage(`Wast engine ready: ${engine}`);
    } catch (e) {
      vscode.window.showErrorMessage(String(e.message || e));
    }
  }));

  context.subscriptions.push(vscode.commands.registerCommand('wast.buildFile', async () => {
    const doc = vscode.window.activeTextEditor?.document;
    if (!doc || doc.languageId !== 'wast') return vscode.window.showWarningMessage('Open a .wast file first.');
    if (doc.isDirty) await doc.save();
    try {
      const cpp = await transpile(context,doc.fileName);
      vscode.window.showInformationMessage(`Wast transpiled: ${path.basename(cpp)}`);
    } catch (e) {
      vscode.window.showErrorMessage(String(e.message || e));
    }
  }));

  context.subscriptions.push(vscode.commands.registerCommand('wast.runFile', async () => {
    const doc = vscode.window.activeTextEditor?.document;
    if (!doc || doc.languageId !== 'wast') return vscode.window.showWarningMessage('Open a .wast file first.');
    if (doc.isDirty) await doc.save();
    try {
      const exe = await buildProgram(context,doc.fileName);
      runInTerminal(doc.fileName,exe);
    } catch (e) {
      vscode.window.showErrorMessage(String(e.message || e));
    }
  }));
}

function deactivate() {}
module.exports = {activate,deactivate};
